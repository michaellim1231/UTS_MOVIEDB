package com.example.moviedb.view.activities;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import com.bumptech.glide.Glide;
import com.example.moviedb.R;
import com.example.moviedb.helper.Const;
import com.example.moviedb.model.Movies;
import com.example.moviedb.viewmodel.MovieViewModel;

import java.util.List;

public class MovieDetailActivity extends AppCompatActivity {

    private ImageView img_poster,img_poster_background;
    private String movie_id = "";
    private MovieViewModel view_model;
    private TextView lbl_title, lbl_date, lbl_desc, lbl_text;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_details);

        Intent intent = getIntent();
        movie_id = intent.getStringExtra("movie_id");
        view_model = new ViewModelProvider(MovieDetailActivity.this).get(MovieViewModel.class);
        view_model.getMovieById(movie_id);
        view_model.getResultGetMovieById().observe(MovieDetailActivity.this, showDetails);

        lbl_title = findViewById(R.id.lbl_title_movie_details);
        lbl_desc = findViewById(R.id.lbl_isi_sinopsis_movie_details);
        lbl_text= findViewById(R.id.lbl_movie_details);
//        lbl_text.setText(movie_id);
        img_poster = findViewById(R.id.poster_movie_details);
        img_poster_background = findViewById(R.id.poster_background);

    }


    private Observer<Movies> showDetails = new Observer<Movies>() {
        @Override
        public void onChanged(Movies movies) {
            if (movies == null) {
                lbl_desc.setText("Movie not Available");
            } else {
                String Title = movies.getTitle();
                String Overview = movies.getOverview();
                String img_path = Const.IMG_URL + movies.getPoster_path().toString();
                Glide.with(MovieDetailActivity.this).load(img_path).into(img_poster);
                String img_path_cover = Const.IMG_URL + movies.getBackdrop_path().toString();
                Glide.with(MovieDetailActivity.this).load(img_path_cover).into(img_poster_background);
                lbl_title.setText(Title);
                lbl_desc.setText(Overview);



                StringBuilder stringBuilder = new StringBuilder();
                for (int i = 0; i < movies.getGenres().size(); i++){
                    if (i != movies.getGenres().size() - 1) {
                        stringBuilder.append(movies.getGenres().get(i).getName() + " ");
                    } else {
                        stringBuilder.append(movies.getGenres().get(i).getName() + " ");
                    }
                }
                lbl_text.setText(stringBuilder);
            }
        }
    };

    @Override
    public void onBackPressed() {
        finish();
    }
}