package com.example.moviedb.view.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.moviedb.R;

import com.example.moviedb.adapter.ProductionCompaniesAdapter;
import com.example.moviedb.helper.Const;
import com.example.moviedb.model.Movies;

import com.example.moviedb.viewmodel.MovieViewModel;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link MovieDetailsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MovieDetailsFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public MovieDetailsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment MovieDetailsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static MovieDetailsFragment newInstance(String param1, String param2) {
        MovieDetailsFragment fragment = new MovieDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
//            mParam1 = getArguments().getString(ARG_PARAM1);
//            mParam2 = getArguments().getString(ARG_PARAM2);
            progressDialog = ProgressDialog.show(getActivity(), "","Please Wait...", true);
            progressDialog.show();
        }
    }
    //TextView for Movie
    private TextView lbl_movie_id,lbl_title, lbl_date, lbl_desc, lbl_popular, lbl_vote, lbl_genre, lbl_tagline, lbl_status;
    private ImageView img_poster_fragment, img_backdrop_fragment;
    private MovieViewModel view_model;
    private Movies movies;
    private String movie_id = "";

    //RecycleView
    private RecyclerView rv_production, rv_cast;
    private ProgressDialog progressDialog;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_movie_details, container, false);

        lbl_movie_id = view.findViewById(R.id.lbl_movie_id_details_fragment);
        lbl_title = view.findViewById(R.id.lbl_title_movie_detail_fragment);
        lbl_desc = view.findViewById(R.id.lbl_overview_detail_fragment);
        lbl_date = view.findViewById(R.id.lbl_release_date_fragment);
        lbl_popular = view.findViewById(R.id.lbl_popularity_fragment);
        lbl_vote = view.findViewById(R.id.lbl_vote_fragment);
        lbl_genre = view.findViewById(R.id.lbl_genre_fragment);
        lbl_tagline = view.findViewById(R.id.lbl_tagline_movie_details);
        lbl_status = view.findViewById(R.id.lbl_status);
        rv_production = view.findViewById(R.id.rv_production_details_fragment);
        rv_cast = view.findViewById(R.id.rv_cast);

        img_poster_fragment = view.findViewById(R.id.poster_detail_fragment);
        img_backdrop_fragment = view.findViewById(R.id.img_details);



        view_model = new ViewModelProvider(getActivity()).get(MovieViewModel.class);

        String movieId = getArguments().getString("movieId");
        view_model.getMovieById(movieId);


        view_model.getResultGetMovieById().observe(getActivity(), showResultMovie);

        String title = getArguments().getString("title");
        String overview = getArguments().getString("overview");
        String date = getArguments().getString("releaseDate");
        String popular = getArguments().getString("popularity");
        String vote = getArguments().getString("vote");


        lbl_title.setText(title);
        lbl_desc.setText(overview);
        lbl_date.setText(date);
        lbl_popular.setText(popular);
        lbl_vote.setText(vote);


        return view;
    }

    private Observer<Movies> showResultMovie = new Observer<Movies>() {
        @Override
        public void onChanged(Movies movies) {
            String tagline = movies.getTagline();
            String status = movies.getStatus();
            String img_path_poster = Const.IMG_URL + movies.getBackdrop_path().toString();
            Glide.with(getActivity()).load(img_path_poster).into(img_poster_fragment);
            String img_path_cover = Const.IMG_URL + movies.getPoster_path().toString();
            Glide.with(getActivity()).load(img_path_cover).into(img_backdrop_fragment);
            lbl_tagline.setText(tagline);
            lbl_status.setText(status);


            StringBuilder stringBuilder = new StringBuilder();
            for (int i = 0; i < movies.getGenres().size(); i++){
                if (i != movies.getGenres().size() - 1) {
                    stringBuilder.append(movies.getGenres().get(i).getName() + " | ");
                } else {
                    stringBuilder.append(movies.getGenres().get(i).getName() + " ");
                }
            }
            lbl_genre.setText(stringBuilder);

            ProductionCompaniesAdapter adapter = new ProductionCompaniesAdapter(getActivity(), movies.getProduction_companies());
            adapter.setProductionCompaniesList(movies.getProduction_companies());
            rv_production.setAdapter(adapter);
            rv_production.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
            progressDialog.dismiss();


        }
    };








}