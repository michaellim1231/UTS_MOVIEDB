package com.example.moviedb.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class Credits implements Parcelable {

    private int id;
    private List<Cast> cast;
    private List<Crew> crew;

    protected Credits(Parcel in) {
        id = in.readInt();
    }

    public static final Creator<Credits> CREATOR = new Creator<Credits>() {
        @Override
        public Credits createFromParcel(Parcel in) {
            return new Credits(in);
        }

        @Override
        public Credits[] newArray(int size) {
            return new Credits[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public List<Cast> getCast() {
        return cast;
    }

    public void setCast(List<Cast> cast) {
        this.cast = cast;
    }

    public List<Crew> getCrew() {
        return crew;
    }

    public void setCrew(List<Crew> crew) {
        this.crew = crew;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(id);
    }

    public static class Cast implements Parcelable{
        private boolean adult;
        private int gender;
        private int id;
        private String known_for_department;
        private String name;
        private String original_name;
        private double popularity;
        private String profile_path;
        private int cast_id;
        private String character;
        private String credit_id;
        private int order;

        protected Cast(Parcel in) {
            adult = in.readByte() != 0;
            gender = in.readInt();
            id = in.readInt();
            known_for_department = in.readString();
            name = in.readString();
            original_name = in.readString();
            popularity = in.readDouble();
            profile_path = in.readString();
            cast_id = in.readInt();
            character = in.readString();
            credit_id = in.readString();
            order = in.readInt();
        }

        public static final Creator<Cast> CREATOR = new Creator<Cast>() {
            @Override
            public Cast createFromParcel(Parcel in) {
                return new Cast(in);
            }

            @Override
            public Cast[] newArray(int size) {
                return new Cast[size];
            }
        };

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKnown_for_department() {
            return known_for_department;
        }

        public void setKnown_for_department(String known_for_department) {
            this.known_for_department = known_for_department;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getProfile_path() {
            return profile_path;
        }

        public void setProfile_path(String profile_path) {
            this.profile_path = profile_path;
        }

        public int getCast_id() {
            return cast_id;
        }

        public void setCast_id(int cast_id) {
            this.cast_id = cast_id;
        }

        public String getCharacter() {
            return character;
        }

        public void setCharacter(String character) {
            this.character = character;
        }

        public String getCredit_id() {
            return credit_id;
        }

        public void setCredit_id(String credit_id) {
            this.credit_id = credit_id;
        }

        public int getOrder() {
            return order;
        }

        public void setOrder(int order) {
            this.order = order;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeByte((byte) (adult ? 1 : 0));
            parcel.writeInt(gender);
            parcel.writeInt(id);
            parcel.writeString(known_for_department);
            parcel.writeString(name);
            parcel.writeString(original_name);
            parcel.writeDouble(popularity);
            parcel.writeString(profile_path);
            parcel.writeInt(cast_id);
            parcel.writeString(character);
            parcel.writeString(credit_id);
            parcel.writeInt(order);
        }
    }

    public static class Crew implements Parcelable{
        private boolean adult;
        private int gender;
        private int id;
        private String known_for_department;
        private String name;
        private String original_name;
        private double popularity;
        private String profile_path;
        private String credit_id;
        private String department;
        private String job;

        protected Crew(Parcel in) {
            adult = in.readByte() != 0;
            gender = in.readInt();
            id = in.readInt();
            known_for_department = in.readString();
            name = in.readString();
            original_name = in.readString();
            popularity = in.readDouble();
            profile_path = in.readString();
            credit_id = in.readString();
            department = in.readString();
            job = in.readString();
        }

        public static final Creator<Crew> CREATOR = new Creator<Crew>() {
            @Override
            public Crew createFromParcel(Parcel in) {
                return new Crew(in);
            }

            @Override
            public Crew[] newArray(int size) {
                return new Crew[size];
            }
        };

        public boolean isAdult() {
            return adult;
        }

        public void setAdult(boolean adult) {
            this.adult = adult;
        }

        public int getGender() {
            return gender;
        }

        public void setGender(int gender) {
            this.gender = gender;
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getKnown_for_department() {
            return known_for_department;
        }

        public void setKnown_for_department(String known_for_department) {
            this.known_for_department = known_for_department;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getOriginal_name() {
            return original_name;
        }

        public void setOriginal_name(String original_name) {
            this.original_name = original_name;
        }

        public double getPopularity() {
            return popularity;
        }

        public void setPopularity(double popularity) {
            this.popularity = popularity;
        }

        public String getProfile_path() {
            return profile_path;
        }

        public void setProfile_path(String profile_path) {
            this.profile_path = profile_path;
        }

        public String getCredit_id() {
            return credit_id;
        }

        public void setCredit_id(String credit_id) {
            this.credit_id = credit_id;
        }

        public String getDepartment() {
            return department;
        }

        public void setDepartment(String department) {
            this.department = department;
        }

        public String getJob() {
            return job;
        }

        public void setJob(String job) {
            this.job = job;
        }

        @Override
        public int describeContents() {
            return 0;
        }

        @Override
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeByte((byte) (adult ? 1 : 0));
            parcel.writeInt(gender);
            parcel.writeInt(id);
            parcel.writeString(known_for_department);
            parcel.writeString(name);
            parcel.writeString(original_name);
            parcel.writeDouble(popularity);
            parcel.writeString(profile_path);
            parcel.writeString(credit_id);
            parcel.writeString(department);
            parcel.writeString(job);
        }
    }
}
