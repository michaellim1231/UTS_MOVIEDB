package com.example.moviedb.view.fragments;

import android.content.Context;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.moviedb.R;
import com.example.moviedb.adapter.NowPlayingAdapter;

import com.example.moviedb.adapter.TopRatedAdapter;
import com.example.moviedb.helper.ItemClickSupport;
import com.example.moviedb.model.NowPlaying;
import com.example.moviedb.model.TopRated;
import com.example.moviedb.viewmodel.MovieViewModel;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link nowPlayingFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class nowPlayingFragment extends Fragment {

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public nowPlayingFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment nowPlayingFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static nowPlayingFragment newInstance(String param1, String param2) {
        nowPlayingFragment fragment = new nowPlayingFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }
    private RecyclerView rv_now_playing,rv_top_rated,rv_Up_Coming;
    private MovieViewModel view_model;
    private Context context;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_now_playing, container, false);

        rv_now_playing = view.findViewById(R.id.rv_now_playing_fragment);
        rv_top_rated = view.findViewById(R.id.rv_top_rated_fragment);

        view_model = new ViewModelProvider(getActivity()).get(MovieViewModel.class);
        view_model.getNowPlaying();
        view_model.getTopRated();

        view_model.getResultNowPlaying().observe(getActivity(), showNowPlaying);
        view_model.getResultTopRated().observe(getActivity(), showTopRated);


        return view;
    }

    private Observer<NowPlaying> showNowPlaying = new Observer<NowPlaying>() {
        @Override
        public void onChanged(NowPlaying nowPlaying) {
            rv_now_playing.setLayoutManager(new LinearLayoutManager(getActivity()));
            NowPlayingAdapter adapter = new NowPlayingAdapter(getActivity());
            adapter.setListNowPlaying(nowPlaying.getResults());
            rv_now_playing.setAdapter(adapter);
            rv_now_playing.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));


            ItemClickSupport.addTo(rv_now_playing).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
                @Override
                public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("movieId", " " + nowPlaying.getResults().get(position).getId());
                    bundle.putString("title", " " + nowPlaying.getResults().get(position).getTitle());
                    bundle.putString("overview", " " + nowPlaying.getResults().get(position).getOverview());
                    bundle.putString("releaseDate", "Release Date: " + nowPlaying.getResults().get(position).getRelease_date());
                    bundle.putString("popularity", "Popularity: " + nowPlaying.getResults().get(position).getPopularity());
                    bundle.putString("vote", " " + nowPlaying.getResults().get(position).getVote_average());

                    Navigation.findNavController(v).navigate(R.id.action_nowPlayingFragment_to_movieDetailsFragment, bundle);
                }
            });


        }
    };

    private Observer<TopRated> showTopRated = new Observer<TopRated>() {
        @Override
        public void onChanged(TopRated topRated) {
            rv_top_rated.setLayoutManager(new LinearLayoutManager(getActivity()));
            TopRatedAdapter adapter = new TopRatedAdapter(getActivity());
            adapter.setListTopRated(topRated.getResults());
            rv_top_rated.setAdapter(adapter);
            rv_top_rated.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

            ItemClickSupport.addTo(rv_top_rated).setOnItemClickListener(new ItemClickSupport.OnItemClickListener() {
                @Override
                public void onItemClicked(RecyclerView recyclerView, int position, View v) {
                    Bundle bundle = new Bundle();
                    bundle.putString("movieId", " " + topRated.getResults().get(position).getId());
                    bundle.putString("title", " " + topRated.getResults().get(position).getTitle());
                    bundle.putString("overview", " " + topRated.getResults().get(position).getOverview());
                    bundle.putString("releaseDate", "Release Date: " + topRated.getResults().get(position).getRelease_date());
                    bundle.putString("popularity", "Popularity: " + topRated.getResults().get(position).getPopularity());
                    bundle.putString("vote", " " + topRated.getResults().get(position).getVote_average());

                    Navigation.findNavController(v).navigate(R.id.action_nowPlayingFragment_to_movieDetailsFragment, bundle);
                }
            });
        }
    };




}