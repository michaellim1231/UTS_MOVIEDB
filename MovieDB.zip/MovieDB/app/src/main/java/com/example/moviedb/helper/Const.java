package com.example.moviedb.helper;

public class Const {

    public static final String API_KEY = "45e4026ae8525d1e36375ebae1afd54e";
    public static final String BASE_URL = "https://api.themoviedb.org/3/";
    public static final String IMG_URL = "https://image.tmdb.org/t/p/w500/";


}
